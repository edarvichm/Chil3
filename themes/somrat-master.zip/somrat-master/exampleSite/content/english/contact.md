---
title : "SAY HELLO!"
bg_image: "images/backgrounds/contact-us-bg.jpg"
form_action: "#" # works with https://formspree
name: "Name"
email: "Email"
message: "Message"
submit: "Submit"


# custom style
custom_class: "" 
custom_attributes: "" 
custom_css: ""
---