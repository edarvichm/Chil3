---
title : "SERVICES"
service_list:
# service item loop
- name : "Web Development"
  image : "images/icons/web-development.png"
  
# service item loop
- name : "Graphic Design"
  image : "images/icons/graphic-design.png"
  
# service item loop
- name : "Database Management"
  image : "images/icons/dbms.png"
  
# service item loop
- name : "Software Development"
  image : "images/icons/software-development.png"
  
# service item loop
- name : "Digital Marketing"
  image : "images/icons/marketing.png"
  
# service item loop
- name : "Mobile App Development"
  image : "images/icons/mobile-app.png"



# custom style
custom_class: "" 
custom_attributes: "" 
custom_css: ""
---