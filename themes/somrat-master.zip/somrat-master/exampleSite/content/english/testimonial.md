---
title : "TESTIMONIALS"
testimonial_slider:
# slider item loop
- name : "Micheal Clark"
  image : "images/clients/client1.jpg"
  designation : "CEO, RANDOM COMPANY"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ad, omnis totam iusto quia? Excepturi itaque quaerat, quia unde delectus rem error dignissimos in iusto."
            
# slider item loop
- name : "Peter Parker"
  image : "images/clients/client2.jpg"
  designation : "CEO, RANDOM COMPANY"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ad, omnis totam iusto quia? Excepturi itaque quaerat, quia unde delectus rem error dignissimos in iusto."
            
# slider item loop
- name : "Jessica Jones"
  image : "images/clients/client3.jpg"
  designation : "CEO, RANDOM COMPANY"
  content : "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ad, omnis totam iusto quia? Excepturi itaque quaerat, quia unde delectus rem error dignissimos in iusto."

# custom style
custom_class: "" 
custom_attributes: "" 
custom_css: ""
---