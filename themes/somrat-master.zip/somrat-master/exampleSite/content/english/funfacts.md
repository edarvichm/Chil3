---
title: ""
bg_image: "images/backgrounds/funfact-bg.jpg"
funfacts:
# funfacts item loop
- name : "HANDS TO WORK"
  image : "images/icons/works.png"
  count : "100"
  
# funfacts item loop
- name : "HAPPY CLIENT"
  image : "images/icons/happy.png"
  count : "200"
  
# funfacts item loop
- name : "FINISHED PROJECT"
  image : "images/icons/project.png"
  count : "250"
  
# funfacts item loop
- name : "CUPS OF COFFEE"
  image : "images/icons/coffee.png"
  count : "150"


# custom style
custom_class: "" 
custom_attributes: "" 
custom_css: ""
---