---
title : "I'm Somrat Sorkar"
# full screen navigation
first_name : "MacGyver"
last_name : "SOMRAT"
bg_image : "images/backgrounds/full-nav-bg.jpg"
# animated text loop
occupations:
- "Web Developer"
- "Graphic Designer"
- "Database Manager"

# slider background image loop
slider_images:
- "images/slider/slider-1.jpg"
- "images/slider/slider-2.jpg"
- "images/slider/slider-3.jpg"

# button
button:
  enable : true
  label : "HIRE ME"
  link : "#contact"


# custom style
custom_class: "" 
custom_attributes: "" 
custom_css: ""

---